package com.servlet.first;

import jakarta.servlet.http.HttpServlet;

public class cretaServlet  implements HttpServlet {
	

}
